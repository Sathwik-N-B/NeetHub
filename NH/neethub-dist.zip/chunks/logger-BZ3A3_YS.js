const n="[NeetHub]";function e(...o){console.log(n,...o)}function r(...o){console.warn(n,...o)}function c(...o){console.error(n,...o)}export{c as e,e as l,r as w};
//# sourceMappingURL=logger-BZ3A3_YS.js.map
